package com.example.dtoex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dto2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
